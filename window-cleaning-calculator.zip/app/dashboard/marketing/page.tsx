import { ComingSoon } from "@/components/dashboard/coming-soon"

export default function MarketingPage() {
  return <ComingSoon />
}
