import { ComingSoon } from "@/components/dashboard/coming-soon"

export default function AnalyticsPage() {
  return <ComingSoon />
}
