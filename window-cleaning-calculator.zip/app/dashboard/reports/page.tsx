import { ComingSoon } from "@/components/dashboard/coming-soon"

export default function ReportsPage() {
  return (
    <div>
      <ComingSoon />
    </div>
  )
}
